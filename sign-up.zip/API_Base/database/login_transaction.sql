-- Login session audit table for AuthController / AuthMiddleware
-- Database: law_officers_application (PostgreSQL)

CREATE TABLE IF NOT EXISTS public.login_transaction (
    id              SERIAL PRIMARY KEY,
    phoneno         VARCHAR(15) NOT NULL,
    ip_address      VARCHAR(45),
    user_agent      TEXT,
    encryption_key  VARCHAR(128) NOT NULL,
    login_ts        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    logout_ts       TIMESTAMP,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_ts      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE public.login_transaction IS 'Tracks user login/logout sessions and encryption keys for API auth';
COMMENT ON COLUMN public.login_transaction.phoneno IS 'User mobile number (10-digit Indian mobile)';
COMMENT ON COLUMN public.login_transaction.encryption_key IS 'Per-session AES key used for encrypted payloads';

CREATE INDEX IF NOT EXISTS idx_login_transaction_phone_active
    ON public.login_transaction (phoneno, is_active)
    WHERE is_active = TRUE;

CREATE INDEX IF NOT EXISTS idx_login_transaction_phone_key_active
    ON public.login_transaction (phoneno, encryption_key, is_active)
    WHERE is_active = TRUE;

-- If you already created the table with sspuserinfo_id, run:
-- ALTER TABLE public.login_transaction RENAME COLUMN sspuserinfo_id TO phoneno;
-- ALTER TABLE public.login_transaction ALTER COLUMN phoneno TYPE VARCHAR(15) USING phoneno::text;
